<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloco de banner';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Exibe um banner na parte superior da loja.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'um erro ocorreu ao enviar o arquivo';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Configurações atualizadas';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Imagem bandeira Top';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Carregar uma imagem para o seu banner de topo. As dimensões recomendadas são 1170 x 65px se você estiver usando o tema padrão.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Do Link';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Digite o link associado à sua bandeira. Ao clicar no banner, o link abre na mesma janela. Se nenhuma conexão for inserido, ele redireciona para a página inicial.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Descrição da faixa';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Favor preencher com uma descrição curta, mas com significado';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
