This package include:

1. Quickstart Demo Package, it allows you install full site as demo site. Just simple extract thif file (OT_Jewelry_Quickstart_Demo_Prestashop_1531.zip) to a folder on your server or local server then do installation as new Fresh Prestashop site

2. If you just need install Theme & module package from exsiting Prestashop site, you should just install OT_Jewelry_Template_Prestashop_Installer_1531.zip file via Module themeinstallator module and then remember upload override file: FrontController.php to /override/classes/controller via ftp 