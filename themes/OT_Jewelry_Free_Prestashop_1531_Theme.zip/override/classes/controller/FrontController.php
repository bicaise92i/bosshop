<?php

class FrontController extends FrontControllerCore
{
	/**
	 * @deprecated 1.5.0
	 */
	public function displayHeader()
	{
		// This method will be removed in 1.6
		Tools::displayAsDeprecated();
		$this->initHeader();
		$hook_header = Hook::exec('displayHeader');
		if ((Configuration::get('PS_CSS_THEME_CACHE') || Configuration::get('PS_JS_THEME_CACHE')) && is_writable(_PS_THEME_DIR_.'cache'))
		{
			// CSS compressor management
			if (Configuration::get('PS_CSS_THEME_CACHE'))
				$this->css_files = Media::cccCSS($this->css_files);
			//JS compressor management
			if (Configuration::get('PS_JS_THEME_CACHE'))
				$this->js_files = Media::cccJs($this->js_files);
		}

		// Call hook before assign of css_files and js_files in order to include correctly all css and javascript files
        $this->context->smarty->assign(array(
			'HOOK_HEADER' => $hook_header,
			'HOOK_TOP' => Hook::exec('displayTop'),
			'HOOK_LEFT_COLUMN' => ($this->display_column_left ? Hook::exec('displayLeftColumn') : ''),
			'HOOK_RIGHT_COLUMN' => ($this->display_column_right ? Hook::exec('displayRightColumn', array('cart' => $this->context->cart)) : ''),
			'HOOK_FOOTER' => Hook::exec('displayFooter'),
			'HOOK_MENUBAR' => Hook::exec('menuBar'),
			'HOOK_BANNER' => Hook::exec('banner'),
			'HOOK_TOPCONTENT' => Hook::exec('topContent'),
			'HOOK_BOTTOMCONTENT' => Module::hookExec('bottomContent'),
			'HOOK_BOTTOM' => Module::hookExec('bottom'),
			'HOOK_TOPBOX' => Module::hookExec('topBox')
		));

		$this->context->smarty->assign('css_files', $this->css_files);
		$this->context->smarty->assign('js_files', array_unique($this->js_files));

		$this->display_header = $display;
		$this->smartyOutputContent(_PS_THEME_DIR_.'header.tpl');

	}

	/**
	 * @deprecated 1.5.0
	 */
	public function displayFooter($display = true)
	{
		// This method will be removed in 1.6
		Tools::displayAsDeprecated();
		$this->smartyOutputContent(_PS_THEME_DIR_.'footer.tpl');
	}
	
	public function initContent()
	{
		$this->process();
		if (!isset($this->context->cart))
			$this->context->cart = new Cart();
		if ($this->context->getMobileDevice() == false)
		{
			// These hooks aren't used for the mobile theme.
			// Needed hooks are called in the tpl files.
			if (!isset($this->context->cart))
				$this->context->cart = new Cart();
			$this->context->smarty->assign(array(
				'HOOK_HEADER' => Hook::exec('displayHeader'),
				'HOOK_TOP' => Hook::exec('displayTop'),
				'HOOK_LEFT_COLUMN' => ($this->display_column_left ? Hook::exec('displayLeftColumn') : ''),
				'HOOK_RIGHT_COLUMN' => ($this->display_column_right ? Hook::exec('displayRightColumn', array('cart' => $this->context->cart)) : ''),
				'HOOK_MENUBAR' => Hook::exec('menuBar'),
				'HOOK_BANNER' => Hook::exec('banner'),
				'HOOK_TOPCONTENT' => Hook::exec('topContent'),
				'HOOK_TOPBOX' => Module::hookExec('topBox'),
			));

			$enable_custom = Configuration::get('custom_tpl');
			if( $enable_custom == 'on'){
				$tpl_params = new StdClass();
				$tpl_params->width = Configuration::get('width');
				$tpl_params->column_layout = Configuration::get('layout');
				$tpl_params->LayoutStyle = Configuration::get('Otcontrol_LayoutStyle');
				
				self::$smarty->assign('tpl_params', $tpl_params);
			}
		}
		else
		{
			$this->context->smarty->assign(array(
				'HOOK_MOBILE_HEADER' => Hook::exec('displayMobileHeader'),
			));
		}
	}
	
		public function initFooter()
	{
		$this->context->smarty->assign(array(
			'HOOK_FOOTER' => Hook::exec('displayFooter'),
			'HOOK_BOTTOMCONTENT' => Module::hookExec('bottomContent'),
			'HOOK_BOTTOM' => Module::hookExec('bottom'),
			'conditions' => Configuration::get('PS_CONDITIONS'),
			'id_cgv' => Configuration::get('PS_CONDITIONS_CMS_ID'),
			'PS_SHOP_NAME' => Configuration::get('PS_SHOP_NAME'),
			'PS_ALLOW_MOBILE_DEVICE' => isset($_SERVER['HTTP_USER_AGENT']) && (bool)Configuration::get('PS_ALLOW_MOBILE_DEVICE') && @filemtime(_PS_THEME_MOBILE_DIR_)
		));
		
		$enable_custom = Configuration::get('custom_tpl');
			if( $enable_custom == 'on'){
				$tpl_params = new StdClass();
				$tpl_params->width = Configuration::get('width');
				$tpl_params->column_layout = Configuration::get('layout');
				$tpl_params->LayoutStyle = Configuration::get('Otcontrol_LayoutStyle');
				
				self::$smarty->assign('tpl_params', $tpl_params);
			}
	}
}

